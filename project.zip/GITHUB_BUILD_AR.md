# بناء موجّه مادة الاجتماعيات 2.1.0

1. ارفع ملف `project.zip` إلى جذر مستودع GitHub.
2. افتح تبويب **Actions**.
3. شغّل workflow باسم **Build APK**.
4. بعد اكتمال البناء حمّل artifact باسم قريب من:
   `mowajeh-smart-apk-v2.1.0`

هذه النسخة لا تحتاج إلى إعداد Cloudflare أو OpenAI.
