# الموجّه الذكي — بناء النسخة النهائية 2.0.0

## رفع المشروع إلى GitHub
1. خذ الملف المضغوط النهائي الذي يحمل اسم `project.zip`.
2. ارفع **هذا الملف نفسه** إلى جذر مستودع GitHub باسم `project.zip`.
3. افتح **Actions**.
4. اختر **Build Mowajeh APK** ثم **Run workflow**.
5. بعد نجاح البناء افتح **Artifacts** وحمّل `mowajeh-smart-apk-v2.0.0`.
6. فك الضغط وثبّت `app-debug.apk`.

> لا ترفع مفاتيح API أو بيانات حقيقية للمعلمين إلى GitHub.

## الموقع
يمكن تشغيل Workflow **Deploy Mowajeh Web** لنشر مجلد `project/web` عبر GitHub Pages.

## لماذا المشروع مضغوط؟
الـWorkflow يفك `project.zip` أولاً، ثم يبني نسخة Android من مجلد المشروع. وGradle ينسخ `web/` تلقائياً إلى Android Assets أثناء البناء، لذلك يبقى الموقع والتطبيق على مصدر واحد ولا تظهر نسخة قديمة من الصفحة.
