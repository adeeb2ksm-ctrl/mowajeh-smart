package com.taani.mowajeh;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,94,89));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        webView.addJavascriptInterface(new ExportBridge(this), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public static class ExportBridge {
        private final Activity activity;
        ExportBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public void saveWord(String html, String fileName) {
            activity.runOnUiThread(() -> {
                try {
                    byte[] bytes = ("\ufeff" + html).getBytes(StandardCharsets.UTF_8);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/msword");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
                        android.net.Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("تعذر إنشاء ملف التنزيل");
                        try (OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                            out.write(bytes);
                        }
                    } else {
                        File dir = activity.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
                        if (dir == null) throw new Exception("مجلد التنزيل غير متاح");
                        if (!dir.exists()) dir.mkdirs();
                        File file = new File(dir, fileName);
                        try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    }
                    Toast.makeText(activity, "تم حفظ ملف Word في مجلد التنزيلات", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(activity, "تعذر حفظ ملف Word: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printPdf(String html, String title) {
            activity.runOnUiThread(() -> {
                WebView printWeb = new WebView(activity);
                printWeb.getSettings().setJavaScriptEnabled(false);
                printWeb.getSettings().setDefaultTextEncodingName("UTF-8");
                printWeb.setBackgroundColor(Color.WHITE);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title);
                        pm.print(title, adapter, new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build());
                    }
                });
                printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
