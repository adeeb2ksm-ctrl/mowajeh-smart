
const KEY='mowajeh-smart-final-v2.1';
const rubric=[
{id:1,item:'خلاصة تفريغ استمارة الزيارات الصفية.',max:30},{id:2,item:'رفع مستوى التحصيل العلمي للمعلمين.',max:10},{id:3,item:'تنفيذ حصص نموذجية وتبادل زيارات.',max:5},{id:4,item:'تحفيز المتعلمين على إنتاج وسائل تعليمية داعمة للمادة.',max:5},{id:5,item:'أعمال المعلم الخاصة بالعمل وتنظيمها (تحضير، خطط، سجل درجات، إلخ).',max:5},{id:6,item:'متابعة أثر التدريب وتطبيقه أثناء العمل.',max:5},{id:7,item:'الحضور الفعال والاجتماعات والأنشطة التطبيقية.',max:5},{id:8,item:'بناء علاقات ودية مع زملاء العمل والمتعلمين.',max:5},{id:9,item:'المتابعة الدورية لأعمال المعلمين وعمل خطة مناسبة لها.',max:5},{id:10,item:'السير بالمقررات الدراسية حسب خطة الوزارة.',max:5},{id:11,item:'ترجمة التعلم النظري إلى مهارات حياتية وجدانية وعملية.',max:10},{id:12,item:'تحليل نتائج الاختبارات والوقوف عليها وعمل معالجات لها.',max:5},{id:13,item:'تفعيل العمل والوسائل المصاحبة للمادة والاستفادة من مصادر التعلم.',max:5}
];
const defaults={teachers:[],visits:[],teacherEvaluations:[],reports:[],tasks:[],settings:{ai:{enabled:true,mode:'local',system:'مساعد تربوي محلي للموجهة د. تهاني عقلان في مادة الاجتماعيات. حلل بيانات التطبيق فقط، ولا تخترع أسماء أو أرقاماً، وحوّل الملاحظات إلى إجراءات عملية قابلة للقياس.'}}};
let state=JSON.parse(localStorage.getItem(KEY)||'null')||structuredClone(defaults); state.teachers ||= [];state.visits ||= [];state.teacherEvaluations ||= [];state.reports ||= [];state.tasks ||= [];state.settings ||= structuredClone(defaults.settings);state.settings.ai ||= structuredClone(defaults.settings.ai);
let page='home';
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const num=v=>{let n=parseFloat(v);return Number.isFinite(n)?n:null};
function save(msg){localStorage.setItem(KEY,JSON.stringify(state));if(msg)toast(msg)}
function toast(msg){let x=document.getElementById('toast');x.textContent=msg;x.classList.add('show');clearTimeout(window._toast);window._toast=setTimeout(()=>x.classList.remove('show'),1900)}
function go(p){page=p;render();window.scrollTo({top:0,behavior:'smooth'})}
function initials(n){return String(n||'مع').trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('')||'مع'}
function teacherProgress(t){let b=num(t.baseline),g=num(t.target),r=num(t.result);if(b===null||g===null||r===null||g===b)return 0;return Math.max(0,Math.min(100,Math.round((r-b)/(g-b)*100)))}
function teacherStatus(t){let p=teacherProgress(t);return p>=80?['متقدم','done']:p>=45?['قيد التطوير','follow']:['يحتاج دعماً','urgent']}
function teacherVisits(name){return state.visits.filter(v=>v.teacher===name)}
function latestEval(name){let a=state.teacherEvaluations.filter(x=>x.teacher===name).sort((a,b)=>String(b.date).localeCompare(String(a.date)));return a[0]||null}
function evalScore(e){if(!e)return null;return Math.round(e.items.reduce((s,x)=>s+num(x.score)||0,0))}
function home(){
 const n=state.teachers.length,vis=state.visits.length,plans=state.tasks.filter(t=>t.status!=='مكتملة').length,done=state.teachers.filter(t=>teacherStatus(t)[1]==='done').length,avg=n?Math.round(state.teachers.reduce((s,t)=>s+teacherProgress(t),0)/n):0;
 const priority=state.teachers.slice().sort((a,b)=>teacherProgress(a)-teacherProgress(b)).slice(0,3); const recent=state.visits.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,4);
 document.getElementById('app').innerHTML=`
 <div class="quick">
  <button class="q-green" onclick="newTeacher()"><span class="qi i-green">＋</span><b>إضافة معلم</b><span>بناء ملف تطويري</span></button>
  <button class="q-blue" onclick="newVisit()"><span class="qi i-blue">✓</span><b>تسجيل زيارة</b><span>ملاحظة · إجراء · أثر</span></button>
  <button class="q-purple" onclick="go('assistant')"><span class="qi i-purple">✦</span><b>المساعد الذكي</b><span>تحليل · قرار · خطة</span></button>
  <button class="q-gold" onclick="go('reports')"><span class="qi i-gold">▧</span><b>التقارير</b><span>تقارير مهنية جاهزة</span></button>
  <button class="q-teal" onclick="go('teacherEvaluation')"><span class="qi i-teal">👥</span><b>تقييم المعلمين</b><span>البطاقة المعتمدة</span></button>
 </div>
 <div class="section-title"><h2>لوحة التطوير الذكية</h2><span class="muted">بياناتك الفعلية · دون تقييم ذاتي</span></div>
 <div class="stats"><div class="card stat"><div class="icon">👥</div><div class="num">${n}</div><div class="label">إجمالي المعلمين</div></div><div class="card stat"><div class="icon">✓</div><div class="num">${vis}</div><div class="label">الزيارات المسجلة</div></div><div class="card stat"><div class="icon">🎯</div><div class="num">${done}</div><div class="label">معلمون متقدمون</div></div><div class="card stat"><div class="icon">📈</div><div class="num">${avg}%</div><div class="label">متوسط تقدم المعلمين</div></div></div>
 <div class="grid" style="margin-top:16px"><div class="card performance"><div class="row" style="justify-content:space-between"><div><b>مؤشر تطور المعلمين</b><div class="muted">هذا المؤشر يقيس تقدم المعلمين فقط، وليس تقييم الموجهة.</div></div><strong style="font-size:25px">${avg}%</strong></div><div class="progress"><i style="width:${avg}%"></i></div><div class="mini-list">${priority.length?priority.map(t=>{let [st,cl]=teacherStatus(t);return `<div class="mini" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.12);color:#fff"><div><strong>${esc(t.name)}</strong><small style="color:#cde9e6">${esc(t.skill||'مجال تطوير غير محدد')}</small></div><span class="badge ${cl}">${st} · ${teacherProgress(t)}%</span></div>`}).join(''):'<div class="empty" style="color:#d5ece9">أضف أول معلم لتبدأ لوحة التطوير.</div>'}</div></div>
 <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">آخر الزيارات</h3><button class="btn secondary small" onclick="go('visits')">عرض الكل</button></div><div class="mini-list">${recent.length?recent.map(v=>`<div class="mini"><div><strong>${esc(v.teacher)}</strong><small>${esc(v.date||'')} · ${esc(v.skill||'')}</small></div><span class="badge ${v.impact?'done':'follow'}">${v.impact?'تم قياس الأثر':'بانتظار الأثر'}</span></div>`).join(''):'<div class="empty">لا توجد زيارات بعد.</div>'}</div><div class="muted" style="margin-top:10px">${plans?`لديك ${plans} مهام متابعة مفتوحة.`:'لا توجد مهام متابعة مفتوحة.'}</div></div></div>
 <div class="ai-banner"><div><div class="ai-title"><span class="robot">✦</span><div><h3>المساعد الذكي</h3><p>حلّل بيانات المعلمين، اكتشف الأولويات، واقترح خطة تطوير قابلة للقياس.</p></div></div><div class="ai-ask"><input id="homeAI" placeholder="مثال: من يحتاج زيارة متابعة؟"><button class="btn" onclick="askFromHome()">تحليل الآن</button></div></div><div class="card" style="background:rgba(255,255,255,.09);border-color:rgba(255,255,255,.12);color:#fff"><b>يستطيع المساعد:</b><div class="muted" style="color:#d4ece9;line-height:2;margin-top:7px">✓ تحليل الزيارات<br>✓ اقتراح المعالجة<br>✓ إعداد تقرير مهني<br>✓ قياس التحسن والأثر</div></div></div>
 <div class="card" style="margin-top:16px;display:flex;align-items:center;gap:15px;flex-wrap:wrap"><img src="assets/logo_school_transparent.png" style="width:80px;height:60px;object-fit:contain"><div><b>فكرة وتنفيذ الدكتورة / تهاني عقلان</b><div class="muted">نظام مهني لتطوير المعلمين وتحويل الزيارات إلى أثر مستدام.</div></div></div>`;
}
function askFromHome(){let q=document.getElementById('homeAI').value.trim()||'حلل أولويات تطوير المعلمين لدي.';go('assistant');setTimeout(()=>{let i=document.getElementById('aiQuestion');if(i){i.value=q;askAI()}},80)}
function teachers(){document.getElementById('app').innerHTML=`<div class="section-title"><h2>المعلمون · ملفات التطوير</h2><button class="btn" onclick="newTeacher()">＋ إضافة معلم</button></div><div class="card" style="margin-bottom:13px"><div class="muted">كل معلم له خط أساس، هدف، نتيجة، زيارات، تقييمات، وخطة متابعة. لا توجد هنا أي درجة لتقييم الموجهة.</div></div><div class="teacher-grid">${state.teachers.length?state.teachers.map(teacherCard).join(''):'<div class="card empty" style="grid-column:1/-1">لم تتم إضافة معلمين بعد.<br><button class="btn" style="margin-top:12px" onclick="newTeacher()">ابدئي بإضافة أول معلم</button></div>'}</div>`}
function teacherCard(t){let p=teacherProgress(t),[st,cl]=teacherStatus(t),ev=latestEval(t.name);return `<div class="card teacher"><div class="teacher-head"><div class="row"><div class="avatar">${esc(initials(t.name))}</div><div><h3>${esc(t.name)}</h3><small>${esc(t.subject||'الاجتماعيات')} · ${esc(t.grade||'')}</small></div></div><span class="badge ${cl}">${st}</span></div><div class="muted" style="margin-top:10px">مجال التطوير: <b>${esc(t.skill||'غير محدد')}</b></div><div class="bar"><i style="width:${p}%"></i></div><div class="row" style="justify-content:space-between"><small>التقدم ${p}%</small><small>${ev?`آخر تقييم: ${evalScore(ev)}/100`:'لم يُقيّم بعد'}</small></div><div class="toolbar" style="margin-top:12px"><button class="btn small" onclick="editTeacher('${esc(t.id)}')">تحرير</button><button class="btn secondary small" onclick="newVisit('${esc(t.id)}')">زيارة</button><button class="btn secondary small" onclick="newTeacherPlan('${esc(t.id)}')">خطة تطوير</button></div></div>`}
function newTeacher(){openModal('إضافة معلم',teacherForm(),()=>{let t={id:crypto.randomUUID(),name:val('t_name'),subject:val('t_subject'),grade:val('t_grade'),skill:val('t_skill'),baseline:val('t_base'),target:val('t_target'),result:val('t_result'),notes:val('t_notes')};if(!t.name)return toast('اكتب اسم المعلم');state.teachers.push(t);save('تمت إضافة المعلم');closeModal();teachers()})}
function editTeacher(id){let t=state.teachers.find(x=>x.id===id);if(!t)return;openModal('تحرير ملف المعلم',teacherForm(t),()=>{Object.assign(t,{name:val('t_name'),subject:val('t_subject'),grade:val('t_grade'),skill:val('t_skill'),baseline:val('t_base'),target:val('t_target'),result:val('t_result'),notes:val('t_notes')});if(!t.name)return toast('اكتب اسم المعلم');save('تم حفظ ملف المعلم');closeModal();teachers()})}
function teacherForm(t={}){return `<div class="form-grid"><div class="field"><label>اسم المعلم</label><input id="t_name" value="${esc(t.name||'')}"></div><div class="field"><label>المادة</label><input id="t_subject" value="${esc(t.subject||'الاجتماعيات')}"></div><div class="field"><label>الصف</label><input id="t_grade" value="${esc(t.grade||'')}"></div><div class="field"><label>مجال التطوير</label><input id="t_skill" placeholder="مثال: إدارة الصف" value="${esc(t.skill||'')}"></div><div class="field"><label>خط الأساس</label><input id="t_base" type="number" value="${esc(t.baseline??'')}"></div><div class="field"><label>الهدف</label><input id="t_target" type="number" value="${esc(t.target??'')}"></div><div class="field"><label>النتيجة الحالية</label><input id="t_result" type="number" value="${esc(t.result??'')}"></div></div><div class="field"><label>ملاحظات</label><textarea id="t_notes">${esc(t.notes||'')}</textarea></div><div class="muted">يمكن ترك الأرقام فارغة حتى يتم جمع خط الأساس ونتيجة المتابعة.</div>`}
function visits(){let list=state.visits.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));document.getElementById('app').innerHTML=`<div class="section-title"><h2>الزيارات الصفية · من الملاحظة إلى الأثر</h2><button class="btn" onclick="newVisit()">＋ تسجيل زيارة</button></div><div class="card" style="margin-bottom:13px"><b>قاعدة الموجه الذكي:</b> كل زيارة تسجل <span class="badge follow">خط الأساس</span> ثم <span class="badge follow">الإجراء</span> ثم <span class="badge follow">المتابعة</span> ثم <span class="badge done">الأثر</span>.</div><div class="mini-list">${list.length?list.map(v=>`<div class="card"><div class="row" style="justify-content:space-between"><div><b>${esc(v.teacher)}</b><div class="muted">${esc(v.date)} · ${esc(v.skill||'')}</div></div><span class="badge ${v.impact?'done':'follow'}">${v.impact?'أثر موثق':'قيد المتابعة'}</span></div><div class="grid2" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px"><div><small>الملاحظة</small><div>${esc(v.baseline||'—')}</div></div><div><small>الإجراء</small><div>${esc(v.action||'—')}</div></div><div><small>موعد المتابعة</small><div>${esc(v.followDate||'—')}</div></div><div><small>النتيجة/الأثر</small><div>${esc(v.impact||'—')}</div></div></div><div class="toolbar" style="margin-top:10px"><button class="btn secondary small" onclick="editVisit('${esc(v.id)}')">تحرير</button><button class="btn small" onclick="measureImpact('${esc(v.id)}')">تسجيل الأثر</button></div></div>`).join(''):'<div class="card empty">لا توجد زيارات مسجلة.</div>'}</div>`}
function newVisit(teacherId=''){let t=state.teachers.find(x=>x.id===teacherId);openModal('تسجيل زيارة صفية',visitForm({teacher:t?.name||''}),()=>{let v={id:crypto.randomUUID(),teacher:val('v_teacher'),date:val('v_date')||new Date().toISOString().slice(0,10),skill:val('v_skill'),baseline:val('v_base'),strength:val('v_strength'),action:val('v_action'),followDate:val('v_follow'),indicator:val('v_indicator'),evidence:val('v_evidence'),followResult:val('v_followResult'),impact:val('v_impact')};if(!v.teacher)return toast('اختر أو اكتب اسم المعلم');state.visits.push(v);state.tasks.push({id:crypto.randomUUID(),title:`متابعة زيارة ${v.teacher}`,due:v.followDate,status:'مفتوحة',teacher:v.teacher});save('تم تسجيل الزيارة وإنشاء متابعة');closeModal();visits()})}
function editVisit(id){let v=state.visits.find(x=>x.id===id);if(!v)return;openModal('تحرير الزيارة',visitForm(v),()=>{Object.assign(v,{teacher:val('v_teacher'),date:val('v_date'),skill:val('v_skill'),baseline:val('v_base'),strength:val('v_strength'),action:val('v_action'),followDate:val('v_follow'),indicator:val('v_indicator'),evidence:val('v_evidence'),followResult:val('v_followResult'),impact:val('v_impact')});save('تم حفظ الزيارة');closeModal();visits()})}
function visitForm(v={}){let opts=state.teachers.map(t=>`<option ${t.name===v.teacher?'selected':''}>${esc(t.name)}</option>`).join('');return `<div class="form-grid"><div class="field"><label>المعلم</label><select id="v_teacher"><option value="">اختر المعلم</option>${opts}</select></div><div class="field"><label>التاريخ</label><input id="v_date" type="date" value="${esc(v.date||new Date().toISOString().slice(0,10))}"></div><div class="field"><label>مجال الزيارة</label><input id="v_skill" value="${esc(v.skill||'')}"></div><div class="field"><label>موعد المتابعة</label><input id="v_follow" type="date" value="${esc(v.followDate||'')}"></div></div><div class="field"><label>خط الأساس / الملاحظة</label><textarea id="v_base">${esc(v.baseline||'')}</textarea></div><div class="field"><label>نقطة قوة</label><textarea id="v_strength">${esc(v.strength||'')}</textarea></div><div class="field"><label>الإجراء العلاجي / التطويري</label><textarea id="v_action">${esc(v.action||'')}</textarea></div><div class="form-grid"><div class="field"><label>مؤشر النجاح</label><input id="v_indicator" value="${esc(v.indicator||'')}"></div><div class="field"><label>الدليل</label><input id="v_evidence" value="${esc(v.evidence||'')}"></div></div><div class="field"><label>نتيجة المتابعة</label><textarea id="v_followResult">${esc(v.followResult||'')}</textarea></div><div class="field"><label>الأثر المقاس</label><textarea id="v_impact" placeholder="ما الذي تغير لدى المعلم بعد الإجراء؟">${esc(v.impact||'')}</textarea></div>`}
function measureImpact(id){let v=state.visits.find(x=>x.id===id);if(!v)return;openModal('قياس أثر الزيارة',`<div class="field"><label>النتيجة التي ظهرت بعد المعالجة</label><textarea id="impactText">${esc(v.impact||'')}</textarea></div><div class="field"><label>الدليل</label><input id="impactEvidence" value="${esc(v.evidence||'')}"></div>`,()=>{v.impact=val('impactText');v.evidence=val('impactEvidence');save('تم توثيق الأثر');closeModal();visits()})}
function teacherEvaluation(){let list=state.teacherEvaluations.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));document.getElementById('app').innerHTML=`<div class="section-title"><h2>تقييم المعلمين</h2><button class="btn" onclick="newTeacherEvaluation()">＋ تقييم جديد</button></div><div class="score-box"><div class="big-score">100</div><div><b>البطاقة المعتمدة للمعلمين</b><div class="muted">13 بنداً · مجموع البطاقة 100، والدرجة النهائية تحسب بقسمة المجموع على 2.</div></div></div><div class="mini-list" style="margin-top:13px">${list.length?list.map(e=>`<div class="card"><div class="row" style="justify-content:space-between"><div><b>${esc(e.teacher)}</b><div class="muted">${esc(e.date)} · الدرجة ${evalScore(e)}/100 · النهائي ${Math.round(evalScore(e)/2)}/50</div></div><button class="btn secondary small" onclick="editTeacherEvaluation('${esc(e.id)}')">تحرير</button></div></div>`).join(''):'<div class="card empty">لا توجد تقييمات للمعلمين بعد.</div>'}</div>`}
function newTeacherEvaluation(existing=null){let e=existing||{id:crypto.randomUUID(),date:new Date().toISOString().slice(0,10),teacher:'',items:rubric.map(x=>({id:x.id,score:0,note:''}))};openModal(existing?'تحرير تقييم المعلم':'تقييم معلم',evalForm(e),()=>{e.teacher=val('e_teacher');e.date=val('e_date');e.items=rubric.map(x=>({id:x.id,score:Math.max(0,Math.min(x.max,num(document.getElementById('score_'+x.id)?.value)||0)),note:document.getElementById('note_'+x.id)?.value||''}));if(!e.teacher)return toast('اختر المعلم');let old=state.teacherEvaluations.findIndex(x=>x.id===e.id);if(old>=0)state.teacherEvaluations[old]=e;else state.teacherEvaluations.push(e);save('تم حفظ تقييم المعلم');closeModal();teacherEvaluation()})}
function editTeacherEvaluation(id){let e=state.teacherEvaluations.find(x=>x.id===id);if(e)newTeacherEvaluation(e)}
function evalForm(e){let options=state.teachers.map(t=>`<option ${t.name===e.teacher?'selected':''}>${esc(t.name)}</option>`).join('');return `<div class="form-grid"><div class="field"><label>المعلم</label><select id="e_teacher"><option value="">اختر المعلم</option>${options}</select></div><div class="field"><label>تاريخ التقييم</label><input id="e_date" type="date" value="${esc(e.date||'')}"></div></div><div class="rubric"><table><thead><tr><th>م</th><th>البند</th><th>الحد</th><th>الدرجة</th><th>ملاحظة</th></tr></thead><tbody>${rubric.map(x=>{let z=e.items.find(a=>a.id===x.id)||{};return `<tr><td>${x.id}</td><td>${esc(x.item)}</td><td>${x.max}</td><td><input id="score_${x.id}" type="number" min="0" max="${x.max}" value="${num(z.score)||0}" style="width:70px"></td><td><input id="note_${x.id}" value="${esc(z.note||'')}" placeholder="ملاحظة"></td></tr>`}).join('')}</tbody></table></div>`}
function reports(){let n=state.teachers.length,vis=state.visits.length,avg=n?Math.round(state.teachers.reduce((s,t)=>s+teacherProgress(t),0)/n):0,withImpact=state.visits.filter(v=>v.impact).length;document.getElementById('app').innerHTML=`<div class="section-title"><h2>التقارير المهنية</h2><div class="row"><button class="btn" onclick="generateReport(false)">تقرير مهني محلي</button><button class="btn gold" onclick="generateReport(true)">تقرير ذكي</button></div></div><div class="stats"><div class="card stat"><div class="num">${n}</div><div class="label">المعلمون</div></div><div class="card stat"><div class="num">${vis}</div><div class="label">الزيارات</div></div><div class="card stat"><div class="num">${withImpact}</div><div class="label">زيارات بأثر موثق</div></div><div class="card stat"><div class="num">${avg}%</div><div class="label">متوسط تقدم المعلمين</div></div></div><div class="card report" style="margin-top:14px"><div class="row" style="justify-content:space-between;align-items:center"><div><b>تقرير التطوير والإشراف</b><p class="muted" style="margin:5px 0 0">تقرير يعمل بالكامل على الجهاز دون اشتراك أو مفتاح API.</p></div><div class="toolbar" style="margin:0"><button class="btn secondary small" onclick="exportWordReport()">📝 وورد</button><button class="btn small" onclick="exportPDFReport()">📄 PDF</button></div></div><div id="reportOut" class="muted" style="margin-top:14px">اضغطي «تقرير مهني محلي» أو «تقرير ذكي» لإنشائه.</div></div><div class="card" style="margin-top:14px"><b>ملاحظة</b><p class="muted">التقرير يركز على تطوير المعلمين وقياس الأثر. لا يعرض ولا يحسب أي درجة خاصة بالموجهة.</p></div><div id="printReportHost" class="print-only"></div>`}

function teacherAnalysis(t){
  const vs=teacherVisits(t.name).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const evs=state.teacherEvaluations.filter(e=>e.teacher===t.name).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const lastEval=evs[evs.length-1]||null;
  const evalPct=lastEval?Math.round(evalScore(lastEval)):null;
  const prevEval=evs.length>1?evs[evs.length-2]:null;
  const evalDelta=(lastEval&&prevEval)?Math.round(evalScore(lastEval)-evalScore(prevEval)):null;
  const p=teacherProgress(t);
  const strengths=[],issues=[],actions=[];
  const allText=[t.skill,t.notes,...vs.map(v=>[v.skill,v.baseline,v.strength,v.action,v.followResult,v.impact,v.indicator].join(' '))].join(' ').toLowerCase();
  const rules=[
    {keys:['إدارة الصف','الصف','انضباط','سلوك','ازدحام'],label:'إدارة الصف',action:'تطبيق روتين واضح لبداية الحصة، توزيع أدوار للمتعلمين، ومراقبة زمن النشاط مع توثيق أثر ذلك في الزيارة القادمة.'},
    {keys:['وسائل','وسيلة','مصادر التعلم','تقنية','عرض','نشاط'],label:'توظيف الوسائل ومصادر التعلم',action:'اختيار وسيلة مرتبطة مباشرة بهدف الدرس، وتوظيفها في نشاط قصير يقيس تعلم الطلبة بدل استخدامها للعرض فقط.'},
    {keys:['تقويم','اختبار','أسئلة','تحصيل','نتائج','درجات'],label:'التقويم وتحليل النتائج',action:'استخدام تقويم تكويني أثناء الدرس، ثم تحليل النتائج وتحديد مهارة واحدة تحتاج معالجة مع دليل قبل/بعد.'},
    {keys:['تخطيط','تحضير','خطة','أهداف'],label:'التخطيط وبناء الدرس',action:'صياغة أهداف قابلة للملاحظة وربط مراحل الدرس بالهدف والأنشطة والتقويم، ثم مراجعة التحضير في الزيارة التالية.'},
    {keys:['مشاركة','تفاعل','تعلم نشط','طلاب','متعلمين'],label:'تفعيل المتعلمين',action:'زيادة الأسئلة المفتوحة والأنشطة التعاونية وإسناد دور واضح للمتعلمين، مع تسجيل دليل على المشاركة.'},
    {keys:['منهج','مقرر','خطة الوزارة','خطة دراسية'],label:'السير بالمقرر',action:'مراجعة خطة السير بالمقرر وتحديد أي فجوة زمنية، ثم وضع معالجة أسبوعية قابلة للمتابعة.'},
    {keys:['تدريب','تطبيق التدريب','أثر التدريب'],label:'تطبيق أثر التدريب',action:'تحويل التدريب السابق إلى ممارسة صفية محددة، ثم توثيق الدليل قبل وبعد التطبيق.'}
  ];
  rules.forEach(r=>{if(r.keys.some(k=>allText.includes(k.toLowerCase()))){issues.push(r.label);actions.push(r.action)}});
  if(lastEval){
    const weak=lastEval.items.map(x=>({x,meta:rubric.find(r=>r.id===x.id)})).filter(z=>z.meta&&num(z.x.score)!==null)
      .map(z=>({name:z.meta.item,score:num(z.x.score)||0,max:z.meta.max,note:z.x.note||''}))
      .sort((a,b)=>(a.score/a.max)-(b.score/b.max)).slice(0,3);
    weak.forEach(w=>{if(w.score/w.max<.7) issues.push(w.name); if(w.note) issues.push('ملاحظة تقييم: '+w.note)});
    const strong=lastEval.items.map(x=>({x,meta:rubric.find(r=>r.id===x.id)})).filter(z=>z.meta)
      .map(z=>({name:z.meta.item,score:num(z.x.score)||0,max:z.meta.max})).sort((a,b)=>(b.score/b.max)-(a.score/a.max)).slice(0,2);
    strong.forEach(s=>{if(s.score/s.max>=.8) strengths.push(s.name)});
  }
  vs.forEach(v=>{if(v.strength) strengths.push(v.strength)});
  const unique=a=>[...new Set(a.filter(Boolean))];
  const recent=vs[vs.length-1]||null, previous=vs.length>1?vs[vs.length-2]:null;
  if(recent && recent.impact) strengths.push('ظهر أثر موثق في آخر متابعة');
  if(recent && !recent.impact) issues.push('آخر زيارة لم يُوثق أثرها بعد');
  const uniqueIssues=unique(issues).slice(0,5), uniqueStrengths=unique(strengths).slice(0,4);
  let status='يحتاج دعماً';
  if(p>=80) status='متقدم';
  else if(p>=45) status='قيد التطوير';
  if(p===0 && evalPct!==null){ status=evalPct>=80?'متقدم':evalPct>=60?'قيد التطوير':'يحتاج دعماً'; }
  let verdict;
  if(p>=80) verdict='التقدم جيد؛ الأولوية الآن هي تثبيت الممارسة ونقلها إلى مواقف صفية متنوعة.';
  else if(p>=45) verdict='هناك تقدم قابل للبناء عليه، لكن يحتاج إلى متابعة مركزة في مجال أو مجالين حتى يتحول التحسن إلى ممارسة مستقرة.';
  else verdict='الحاجة التطويرية مرتفعة نسبيًا؛ يفضل عدم توزيع الجهد على عدة أهداف، بل اختيار أولوية واحدة قابلة للقياس ثم متابعة أثرها.';
  const nextAction=actions[0]||(
    uniqueIssues[0]&&uniqueIssues[0].includes('تقويم')?'تحليل نتيجة تعلم واحدة وتطبيق معالجة محددة ثم قياس أثرها.':
    uniqueIssues[0]&&uniqueIssues[0].includes('وسائل')?'تنفيذ نشاط واحد بوسيلة تعليمية مرتبطة بالهدف وتوثيق أثرها.':
    uniqueIssues[0]&&uniqueIssues[0].includes('تخطيط')?'مراجعة تحضير درس واحد وربط الهدف بالنشاط والتقويم.':
    'تنفيذ زيارة متابعة مركزة على مجال التطوير المسجل، مع تحديد دليل نجاح قبل الزيارة.'
  );
  return {t,vs,evs,lastEval,evalPct,evalDelta,p,status,verdict,issues:uniqueIssues,strengths:uniqueStrengths,nextAction,recent,previous};
}
function allAnalyses(){return state.teachers.map(teacherAnalysis)}
function findTeacherInQuestion(q){
  const s=String(q||'').toLowerCase();
  return state.teachers.find(t=>s.includes(String(t.name||'').toLowerCase()))||null;
}
function analysisText(a){
  const t=a.t;
  const lines=[];
  lines.push(`تحليل ${t.name}`);
  lines.push(`الحالة الحالية: ${a.status}`);
  if(a.p>0) lines.push(`مؤشر التقدم من خط الأساس إلى الهدف: ${a.p}%.`);
  if(a.evalPct!==null) lines.push(`آخر تقييم للمعلم: ${a.evalPct}/100${a.evalDelta!==null?`، والتغير عن التقييم السابق: ${a.evalDelta>0?'+':''}${a.evalDelta}`:''}.`);
  lines.push(`الزيارات المسجلة: ${a.vs.length}، والزيارات ذات الأثر الموثق: ${a.vs.filter(v=>v.impact).length}.`);
  lines.push(`الاستنتاج المهني: ${a.verdict}`);
  if(a.strengths.length) lines.push('نقاط القوة: '+a.strengths.join('، ')+'.');
  if(a.issues.length) lines.push('الأولويات المكتشفة: '+a.issues.join('، ')+'.');
  if(a.recent){
    if(a.recent.baseline) lines.push('من آخر زيارة: الملاحظة/خط الأساس: '+a.recent.baseline+'.');
    if(a.recent.action) lines.push('الإجراء السابق: '+a.recent.action+'.');
    if(a.recent.impact) lines.push('الأثر الموثق: '+a.recent.impact+'.');
    else lines.push('الأثر: لم يُوثق بعد؛ لذلك لا يمكن اعتبار المعالجة مكتملة.');
  }
  lines.push('الإجراء التطويري المقترح الآن: '+a.nextAction);
  lines.push('مؤشر النجاح المقترح: '+(a.recent?.indicator||'ظهور تحسن قابل للملاحظة في المجال المستهدف مع دليل موثق في الزيارة القادمة.') );
  return lines.join('\n');
}
function buildSmartLocalReport(){
  const aa=allAnalyses();
  const avg=aa.length?Math.round(aa.reduce((s,a)=>s+(a.p||0),0)/aa.length):0;
  const pending=state.visits.filter(v=>!v.impact);
  let out=['التقرير الذكي للتطوير والإشراف التربوي','',`التاريخ: ${new Date().toLocaleDateString('ar-YE')}`,`عدد المعلمين: ${aa.length}`,`عدد الزيارات: ${state.visits.length}`,`متوسط مؤشر التقدم: ${avg}%`,''];
  out.push('القراءة العامة');
  out.push(aa.length?`تم تحليل ملفات المعلمين والزيارات والتقييمات والملاحظات المتاحة. متوسط مؤشر التقدم الحالي للمعلمين هو ${avg}%.`:'لا توجد بيانات كافية للتحليل.');
  aa.slice().sort((a,b)=>a.p-b.p).forEach((a,i)=>{
    out.push('',`━━ ${i+1}. ${a.t.name} ━━`);
    out.push(`الحالة: ${a.status}${a.p?` · مؤشر التقدم ${a.p}%`:''}${a.evalPct!==null?` · آخر تقييم ${a.evalPct}/100`:''}`);
    out.push(`القراءة المهنية: ${a.verdict}`);
    if(a.strengths.length) out.push('نقاط القوة: '+a.strengths.join('، ')+'.');
    if(a.issues.length) out.push('ما يحتاج تطويراً: '+a.issues.join('، ')+'.');
    if(a.recent){
      if(a.recent.baseline) out.push('الملاحظة الأخيرة: '+a.recent.baseline+'.');
      if(a.recent.action) out.push('الإجراء الذي تم اتخاذه: '+a.recent.action+'.');
      out.push(a.recent.impact?'الأثر الموثق: '+a.recent.impact+'.':'الأثر غير موثق حتى الآن؛ المتابعة ضرورية.');
    }
    out.push('الإجراء القادم المقترح: '+a.nextAction);
    out.push('مؤشر النجاح: '+(a.recent?.indicator||'تحسن قابل للملاحظة مع دليل موثق في الزيارة القادمة.'));
  });
  out.push('','خطة المتابعة الذكية');
  if(pending.length){
    pending.slice(0,8).forEach((v,i)=>out.push(`${i+1}. ${v.teacher}: استكمال قياس أثر الإجراء "${v.action||'غير محدد'}"${v.followDate?` في ${v.followDate}`:''}.`));
  }else out.push('لا توجد زيارات بلا أثر موثق حالياً.');
  out.push('','قرار المتابعة');
  if(aa.length){
    const top=aa.slice().sort((a,b)=>a.p-b.p)[0];
    out.push(`تبدأ الأولوية بـ ${top.t.name} لأن بياناته الحالية تشير إلى ${top.status}${top.issues.length?' مع وجود حاجة في '+top.issues.slice(0,2).join(' و'):''}.`);
  }else out.push('أضيفي المعلمين والزيارات والتقييمات للحصول على قرار متابعة مبني على البيانات.');
  return out.join('\n');
}
function buildLocalReport(){ return buildSmartLocalReport(); }
let lastReportText='';

function reportToHtml(text){let lines=text.split('\n'),html='<div class="report-print"><h1>'+esc(lines.shift()||'تقرير مهني')+'</h1><div class="meta">موجّه مادة الاجتماعيات · فكرة وتنفيذ الدكتورة / تهاني عقلان</div>';let inList=false;for(const line of lines){if(!line.trim()){if(inList){html+='</ul>';inList=false}continue}if(/^\d+\./.test(line)){if(!inList){html+='<ol>';inList=true}html+='<li>'+esc(line.replace(/^\d+\.\s*/,''))+'</li>';continue}if(line.startsWith('• ')){if(!inList){html+='<ul>';inList=true}html+='<li>'+esc(line.slice(2))+'</li>';continue}if(inList){html+='</'+(line.match(/^\d+\./)?'ol':'ul')+'>';inList=false}if(/^(الخلاصة|أولويات المتابعة|الزيارات التي تحتاج|خطة العمل المقترحة|أولويات التطوير|المجالات المتكررة|المتابعات التي تحتاج|التوصيات العملية|تقرير التطوير والإشراف التربوي)/.test(line)){html+='<h2>'+esc(line)+'</h2>'}else{html+='<div class="box">'+esc(line)+'</div>'}}if(inList)html+='</ul>';html+='<div class="footer">تم إنشاء التقرير محلياً داخل تطبيق الموجّه الذكي. لا يتطلب اشتراكاً أو مفتاح API.</div></div>';return html}
function generateReport(ai){let out=document.getElementById('reportOut');if(!out)return;lastReportText=ai?buildSmartLocalReport():buildLocalReport();out.innerHTML=reportToHtml(lastReportText);out.className='report';state.reports.push({id:crypto.randomUUID(),date:new Date().toISOString(),type:ai?'ذكي محلي':'مهني محلي',text:lastReportText});save();toast('تم إنشاء التقرير ويمكن تصديره وورد أو PDF')}
function exportWordReport(){if(!lastReportText)lastReportText=buildLocalReport();let html='<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير الموجّه الذكي</title><style>body{font-family:Arial,Tahoma,sans-serif;direction:rtl;text-align:right;color:#17363d;line-height:1.9;margin:35px}h1{color:#087f78;font-size:24px}h2{color:#087f78;border-bottom:1px solid #9fc9c4;padding-bottom:5px;margin-top:22px}li{margin:6px 0}.box{border:1px solid #d7e7e4;padding:8px;margin:7px 0}.footer{margin-top:25px;border-top:1px solid #ccc;padding-top:10px;color:#60757a}</style></head><body>'+reportToHtml(lastReportText)+'</body></html>';if(window.Android?.saveWord){window.Android.saveWord(html,'تقرير_الموجه_الذكي.doc');return}let blob=new Blob(['\ufeff',html],{type:'application/msword'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='تقرير_الموجه_الذكي.doc';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('تم تجهيز ملف Word')}
function exportPDFReport(){if(!lastReportText)lastReportText=buildLocalReport();let html='<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير الموجّه الذكي</title><style>body{font-family:Arial,Tahoma,sans-serif;direction:rtl;text-align:right;color:#17363d;line-height:1.9;margin:0}'+'.report-print{padding:28px}.report-print h1{font-size:26px;margin:0 0 6px}.report-print h2{font-size:18px;margin:22px 0 8px;border-bottom:2px solid #087f78;padding-bottom:5px}.report-print .meta{color:#587278;font-size:12px}.report-print .box{border:1px solid #d7e7e4;border-radius:10px;padding:10px;margin:8px 0}.report-print .footer{margin-top:30px;padding-top:10px;border-top:1px solid #ccdedd;font-size:11px;color:#60757a}li{margin:5px 0}</style></head><body>'+reportToHtml(lastReportText)+'</body></html>';if(window.Android?.printPdf){window.Android.printPdf(html,'تقرير_الموجه_الذكي');return}let w=window.open('','_blank');if(!w){toast('اسمحي بفتح نافذة التقرير ثم حاولي مرة أخرى');return}w.document.open();w.document.write(html);w.document.close();setTimeout(()=>{w.focus();w.print()},700)}

function assistant(){document.getElementById('app').innerHTML=`<div class="section-title"><h2>المساعد الذكي</h2><span class="ai-ok">🟢 ذكاء محلي مجاني</span></div><div class="ai-banner"><div><div class="ai-title"><span class="robot">✦</span><div><h3>مساعد د. تهاني عقلان</h3><p>مساعد ذكي يعمل داخل الجهاز دون اشتراك أو مفتاح API أو إرسال بيانات للخارج.</p></div></div><div class="ai-ask"><input id="aiQuestion" placeholder="اسأل: من يحتاج زيارة متابعة؟ أو اقترح خطة لمعلم..." onkeydown="if(event.key==='Enter')askAI()"><button class="btn" onclick="askAI()">اسأل الآن</button></div></div></div><div class="card" style="margin-top:15px"><b>أسئلة سريعة</b><div class="toolbar" style="margin-top:10px"><button class="btn secondary small" onclick="quickAI('حلل أولويات المعلمين لدي.')">حلل الأولويات</button><button class="btn secondary small" onclick="quickAI('من يحتاج زيارة متابعة ولماذا؟')">من يحتاج متابعة؟</button><button class="btn secondary small" onclick="quickAI('اقترح خطة تطوير لمعلم متعثر.')">خطة تطوير</button><button class="btn secondary small" onclick="quickAI('اكتب تقريراً مهنياً عن آخر الزيارات.')">تقرير الزيارات</button></div></div><div id="aiAnswer" class="card" style="margin-top:13px"><div class="muted">سيظهر التحليل هنا. جميع المعالجة محلية على الجهاز.</div></div>`}
function quickAI(q){document.getElementById('aiQuestion').value=q;askAI()}

function localAI(q){
  const question=String(q||'').trim();
  const ql=question.toLowerCase();
  const named=findTeacherInQuestion(question);
  const aa=allAnalyses();
  if(!aa.length) return 'لا أستطيع إجراء تحليل فعلي بعد لأن قاعدة البيانات لا تحتوي على معلمين. ابدئي بإضافة معلم ثم سجلي زيارة أو تقييماً، وسأبني التحليل من البيانات المدخلة.';
  if(named) return analysisText(teacherAnalysis(named));
  if(ql.includes('تقرير')) return buildSmartLocalReport();
  if(ql.includes('خطة')||ql.includes('تطوير')){
    const a=(named?teacherAnalysis(named):aa.slice().sort((x,y)=>x.p-y.p)[0]);
    return `خطة تطوير مخصصة لـ ${a.t.name}\n\n${analysisText(a)}\n\nخطة التنفيذ:\n1. ${a.nextAction}\n2. تنفيذ الإجراء في موقف صفي حقيقي.\n3. جمع دليل محدد على التطبيق.\n4. قياس الأثر في زيارة المتابعة ومقارنة النتيجة بما قبل الإجراء.`;
  }
  if(ql.includes('من يحتاج')||ql.includes('أولوية')||ql.includes('زيارة')||ql.includes('متابعة')){
    const ranked=aa.slice().sort((a,b)=>a.p-b.p);
    return 'ترتيب الحاجة للمتابعة بناءً على البيانات الحالية:\n\n'+ranked.map((a,i)=>`${i+1}. ${a.t.name} — ${a.status}${a.p?` — تقدم ${a.p}%`:''}${a.issues.length?` — أبرز حاجة: ${a.issues[0]}`:''}${a.recent&&!a.recent.impact?' — أثر غير موثق':''}`).join('\n')+
      '\n\nالأولوية الأولى: '+ranked[0].t.name+'\nالسبب: '+ranked[0].verdict;
  }
  if(ql.includes('ضعف')||ql.includes('نقاط')||ql.includes('مشكلات')||ql.includes('مجال')){
    const issues={};
    aa.forEach(a=>a.issues.forEach(i=>issues[i]=(issues[i]||0)+1));
    const top=Object.entries(issues).sort((a,b)=>b[1]-a[1]);
    return top.length?'المجالات الأكثر تكراراً في بيانات المعلمين:\n\n'+top.slice(0,8).map((x,i)=>`${i+1}. ${x[0]} — ظهر لدى ${x[1]} معلم/معلمين.`).join('\n')+'\n\nهذه قراءة من البيانات المدخلة وليست حكماً ثابتاً؛ يمكن تعديل الأولويات بعد زيارة المتابعة.':'لم تظهر مجالات ضعف متكررة بما يكفي من البيانات الحالية.';
  }
  if(ql.includes('تحسن')||ql.includes('أثر')||ql.includes('تقدم')){
    return aa.map(a=>`${a.t.name}: ${a.p?`مؤشر التقدم ${a.p}%`:'لا توجد أرقام كافية لحساب مؤشر التقدم'}${a.evalPct!==null?`، آخر تقييم ${a.evalPct}/100`:''}${a.evalDelta!==null?`، تغير التقييم ${a.evalDelta>0?'+':''}${a.evalDelta}`:''}${a.recent?.impact?`، أثر موثق: ${a.recent.impact}`:'، الأثر غير موثق'}`).join('\n');
  }
  const a=aa.slice().sort((x,y)=>x.p-y.p)[0];
  return `حللت بيانات ${aa.length} من المعلمين والزيارات والتقييمات المتاحة.\n\nأبرز نتيجة الآن:\n${analysisText(a)}\n\nيمكنك أيضاً أن تسألي: «حلل ${a.t.name}»، «من يحتاج متابعة؟»، «ما نقاط الضعف المتكررة؟»، أو «أنشئ تقريراً».`;
}
async function askAI(){
  const q=document.getElementById('aiQuestion')?.value.trim();
  if(!q)return toast('اكتبي السؤال أولاً');
  const out=document.getElementById('aiAnswer');
  out.innerHTML='<div class="muted">جاري تحليل بيانات المعلمين والزيارات والتقييمات…</div>';
  const ans=localAI(q);
  setTimeout(()=>{out.innerHTML='<pre style="white-space:pre-wrap;font-family:inherit;line-height:2;margin:0">'+esc(ans)+'</pre>'},180);
}
async function callAI(question){return localAI(question)}
function settings(){document.getElementById('app').innerHTML=`<div class="section-title"><h2>الإعدادات</h2></div><div class="card"><h3 style="margin-top:0">محرك الذكاء التربوي</h3><div class="ai-settings"><div class="row" style="justify-content:space-between"><div><b>مساعد ذكي مجاني يعمل داخل الجهاز</b><div class="muted">لا يحتاج OpenAI أو Cloudflare أو مفتاح API أو اشتراكاً. بيانات المعلمين والزيارات تبقى على الجهاز.</div></div><span class="ai-ok">🟢 مفعّل</span></div><div class="field" style="margin-top:13px"><label>نمط التشغيل</label><input value="محلي 100% · بدون خدمات مدفوعة" disabled></div><div class="field"><label>وظائف المساعد</label><textarea disabled>تحليل أولويات المعلمين، اقتراح خطط التطوير، اكتشاف الزيارات التي تحتاج متابعة، قياس التقدم، وإنشاء تقارير مهنية.</textarea></div><div class="toolbar"><button class="btn" onclick="toast('المساعد المحلي يعمل دون اتصال أو اشتراك')">اختبار المساعد</button></div></div></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">النسخ الاحتياطي</h3><p class="muted">احفظ بيانات المعلمين والزيارات والتقييمات والتقارير في ملف JSON، واستعدها لاحقاً.</p><div class="toolbar"><button class="btn" onclick="exportData()">تصدير نسخة احتياطية</button><label class="btn secondary" style="display:inline-block">استيراد<input type="file" accept="application/json" hidden onchange="importData(event)"></label></div></div><div class="card" style="margin-top:14px"><h3 style="margin-top:0">هوية التطبيق</h3><div class="row"><img src="assets/logo_school_transparent.png" style="width:90px;height:70px;object-fit:contain"><div><b>فكرة وتنفيذ الدكتورة / تهاني عقلان</b><div class="muted">الموجّه الذكي · مادة الاجتماعيات</div></div></div><div class="cover-note">الإصدار النهائي 2.1 · ذكاء محلي مجاني · بيانات العمل محلية على الجهاز.</div></div>`}

function resources(){document.getElementById('app').innerHTML=`<div class="section-title"><h2>مركز العمل والموارد</h2></div><div class="resource-grid"><div class="card resource"><span class="ri">📝</span><div><b>خطة تطوير معلم</b><div class="muted">خط أساس · هدف · إجراء · مؤشر · متابعة · أثر</div></div><button class="btn small" onclick="newTeacherPlan()">إنشاء</button></div><div class="card resource"><span class="ri">📚</span><div><b>بنك الأسئلة</b><div class="muted">مساحة لحفظ وتصنيف الأسئلة.</div></div><button class="btn secondary small" onclick="toast('تم تجهيز مساحة بنك الأسئلة')">فتح</button></div><div class="card resource"><span class="ri">🎓</span><div><b>حصة نموذجية</b><div class="muted">تخطيط وتبادل خبرات.</div></div><button class="btn secondary small" onclick="toast('تم تجهيز مساحة الحصص النموذجية')">فتح</button></div><div class="card resource"><span class="ri">📊</span><div><b>تحليل نتائج</b><div class="muted">ربط نتائج الاختبارات بالمعالجة.</div></div><button class="btn secondary small" onclick="toast('يمكن إضافة التحليل من ملف المعلم')">فتح</button></div></div>`}
function newTeacherPlan(teacherId=''){let t=state.teachers.find(x=>x.id===teacherId);openModal('خطة تطوير معلم',`<div class="field"><label>المعلم</label><select id="p_teacher"><option value="">اختر المعلم</option>${state.teachers.map(x=>`<option ${x.name===t?.name?'selected':''}>${esc(x.name)}</option>`).join('')}</select></div><div class="field"><label>الفجوة / المهارة المستهدفة</label><input id="p_gap" value="${esc(t?.skill||'')}"></div><div class="field"><label>الإجراء</label><textarea id="p_action">تحديد إجراء عملي واحد قابل للتطبيق داخل الصف.</textarea></div><div class="field"><label>مؤشر النجاح</label><input id="p_indicator" placeholder="مثال: تحسن واضح في إدارة وقت الحصة"></div><div class="field"><label>موعد المتابعة</label><input id="p_due" type="date"></div>`,()=>{let task={id:crypto.randomUUID(),title:`خطة تطوير ${val('p_teacher')}`,teacher:val('p_teacher'),gap:val('p_gap'),action:val('p_action'),indicator:val('p_indicator'),due:val('p_due'),status:'مفتوحة'};state.tasks.push(task);save('تم إنشاء خطة التطوير');closeModal()})}
function openModal(title,html,onSave){document.getElementById('sheet').innerHTML=`<div class="row" style="justify-content:space-between"><h2>${esc(title)}</h2><button class="btn secondary small" onclick="closeModal()">إغلاق</button></div>${html}<div class="toolbar" style="justify-content:flex-start;margin-top:14px"><button class="btn" onclick="window._modalSave()">حفظ</button><button class="btn secondary" onclick="closeModal()">إلغاء</button></div>`;window._modalSave=onSave;document.getElementById('modal').classList.add('show')}
function closeModal(){document.getElementById('modal').classList.remove('show');window._modalSave=null}
function val(id){return document.getElementById(id)?.value?.trim()||''}
function exportData(){let blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='mowajeh-smart-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);toast('تم تصدير النسخة الاحتياطية')}
function importData(ev){let f=ev.target.files?.[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let d=JSON.parse(r.result);if(!d||!Array.isArray(d.teachers)||!Array.isArray(d.visits))throw 0;state={...defaults,...d,settings:{...defaults.settings,...(d.settings||{}),ai:{...defaults.settings.ai,mode:'local',enabled:true}}};save('تم استيراد البيانات');settings()}catch(e){toast('ملف غير صالح')}};r.readAsText(f)}
function render(){document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));({home,teachers,visits,teacherEvaluation,reports,assistant,resources,settings}[page]||home)()}
render();
