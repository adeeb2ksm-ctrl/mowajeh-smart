const ALLOWED_METHODS = new Set(["POST", "OPTIONS"]);
const MAX_BODY = 220 * 1024;
const MODEL_DEFAULT = "gpt-4o-mini";
const SYSTEM_DEFAULT = "أنت مساعد تربوي مهني للموجهة د. تهاني عقلان في مادة الاجتماعيات في اليمن. قدم خططاً عملية قابلة للقياس، ولا تخترع بيانات غير موجودة.";

function cors(origin, env) {
  // The API key is never exposed; CORS only controls browser access.
  // If ALLOWED_ORIGIN is set, the public web app is restricted to that origin.
  const configured = env?.ALLOWED_ORIGIN?.trim();
  const allow = configured ? ((origin === "*" || origin === "null" || origin === configured) ? (origin === configured ? origin : "*") : "null") : (origin || "*");
  return {
    "Access-Control-Allow-Origin": allow,
    "Access-Control-Allow-Headers": "Content-Type, X-Mowajeh-Client",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin"
  };
}

function json(data, status, origin, env) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...cors(origin, env) }
  });
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "*";
    if (!ALLOWED_METHODS.has(request.method)) return json({ error: "Method not allowed" }, 405, origin, env);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(origin, env) });

    if (!env.OPENAI_API_KEY) return json({ error: "OPENAI_API_KEY is not configured on the proxy server." }, 500, origin, env);
    if (request.headers.get("Content-Length") && Number(request.headers.get("Content-Length")) > MAX_BODY) return json({ error: "Request too large" }, 413, origin, env);

    let body;
    try {
      const raw = await request.text();
      if (raw.length > MAX_BODY) return json({ error: "Request too large" }, 413, origin, env);
      body = JSON.parse(raw);
    } catch (_) {
      return json({ error: "Invalid JSON" }, 400, origin, env);
    }

    if (!Array.isArray(body.messages) || body.messages.length === 0) return json({ error: "messages is required" }, 400, origin, env);

    const upstreamBody = {
      model: body.model || MODEL_DEFAULT,
      messages: [
        { role: "system", content: body.system || SYSTEM_DEFAULT },
        ...body.messages
      ],
      temperature: typeof body.temperature === "number" ? body.temperature : 0.3
    };

    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(upstreamBody)
    });

    const text = await upstream.text();
    return new Response(text, {
      status: upstream.status,
      headers: { "Content-Type": "application/json; charset=utf-8", ...cors(origin, env) }
    });
  }
};
