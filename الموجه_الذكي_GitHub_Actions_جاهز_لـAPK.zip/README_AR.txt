مشروع Android لتطبيق «الموجه الذكي – اجتماعيات اليمن».

تم تضمين واجهة التطبيق وكل الصور داخل app/src/main/assets، لذلك يعمل المحتوى بدون إنترنت.

لإخراج APK:
1) افتح المجلد في Android Studio.
2) انتظر مزامنة Gradle وتنزيل Android SDK/Gradle Plugin إذا طلب البرنامج ذلك.
3) اختر Build > Build APK(s).
4) ملف APK سيكون عادة في: app/build/outputs/apk/debug/app-debug.apk

ملاحظة: بيئة إنشاء الملفات الحالية لا تحتوي على Android SDK/Gradle ولا تسمح بتنزيلهما، لذلك تم تجهيز مشروع Android قابل للبناء بدلاً من الادعاء بوجود APK مبني.
