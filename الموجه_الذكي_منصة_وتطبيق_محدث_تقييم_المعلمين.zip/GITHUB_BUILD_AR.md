# الموجه الذكي — بناء APK من الهاتف

## الطريقة
1. أنشئ مستودعاً جديداً على GitHub.
2. ارفع **كل محتويات هذا المجلد** إلى المستودع، وليس ملف ZIP نفسه.
3. من GitHub افتح تبويب **Actions**.
4. اختر **Build APK**.
5. اضغط **Run workflow**.
6. انتظر انتهاء البناء.
7. افتح نتيجة التشغيل ثم قسم **Artifacts**.
8. نزّل `mowajeh-smart-apk.zip` إلى الهاتف وفك الضغط.
9. ستجد داخله ملف `app-debug.apk` لتثبيته.

## ملاحظات
- لا يحتاج إلى Android Studio.
- GitHub يبني APK في السحابة باستخدام Android SDK.
- الـAPK الناتج Debug APK ومناسب للتجربة والتثبيت الشخصي.
- لا ترفع بيانات حقيقية للمعلمين أو التقارير إلى المستودع. المشروع فقط؛ البيانات المحلية الموجودة على الهاتف لا تنتقل إلى GitHub.


## التحديث الجديد
بعد رفع المشروع إلى GitHub: افتح Actions ثم Build Mowajeh APK ثم Run workflow. البناء يستخدم Gradle 8.7 مباشرة، وبعد النجاح يظهر ملف APK في Artifacts باسم `mowajeh-smart-apk`.

لنشر نسخة الموقع: فعّل GitHub Pages من Settings > Pages واختر GitHub Actions، ثم شغّل `Deploy Web Platform`.
